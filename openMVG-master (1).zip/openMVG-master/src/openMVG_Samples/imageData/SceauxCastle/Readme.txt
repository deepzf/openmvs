Image of "Chateau de Sceaux", Sceaux castle. France.
Photographer: Copyright 2012 Pierre MOULON http://imagine.enpc.fr/~moulonp/
