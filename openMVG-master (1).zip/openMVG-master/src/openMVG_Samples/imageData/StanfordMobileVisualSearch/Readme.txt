DVD cover images, Stanford mobile visual search database
(http://www.stanford.edu/~dmchen/mvs.html) 
by V.R. Chandrasekhar, D.M. Chen et al.

