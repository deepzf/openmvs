**********************
3D point cloud handler
**********************

PLY point cloud export (PLY is known as the Polygon File Format or the Stanford Triangle Format).

	Different interfaces have been written in order to export:

	- Point cloud,
	- Coloured point cloud,
	- Camera location.
